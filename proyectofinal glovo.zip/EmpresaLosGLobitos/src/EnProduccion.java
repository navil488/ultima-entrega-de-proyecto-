
public class EnProduccion implements EstadoProducto {
    public void manejar(Producto producto) {
        System.out.println("El producto está en producción.");
    }
}