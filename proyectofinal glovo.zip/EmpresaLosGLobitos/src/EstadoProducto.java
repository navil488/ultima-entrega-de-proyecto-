public interface EstadoProducto {
    void manejar(Producto producto);
}

