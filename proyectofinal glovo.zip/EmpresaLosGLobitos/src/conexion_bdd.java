import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion_bdd {

    // Cambia el driver a MariaDB
    private static String driver = "org.mariadb.jdbc.Driver";
    private static String usuario = "root"; // Asegúrate que el usuario esté bien configurado
    private static String password = "root";
    private static String url = "jdbc:mariadb://localhost:3307/software"; // Cambia a 'mariadb'

    static {
        try {
            Class.forName(driver);
            System.out.println("Conexión con MariaDB exitosa.");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Error en el driver.");
        }
    }

    Connection con = null;

    public Connection getConnection() {
        try {
            con = DriverManager.getConnection(url, usuario, password);
            System.out.println("Conectado a MariaDB.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error de conexión.");
        }
        return con;
    }

    public void closeConnection() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Se cerró la conexión exitosamente.");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al cerrar la conexión.");
            }
        }
    }

    public static void main(String[] args) {
        conexion_bdd db = new conexion_bdd();
        db.getConnection();
        
        
        
        
        // Cierra la conexión después de usarla
        db.closeConnection();
    }
}
