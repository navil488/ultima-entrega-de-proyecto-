public class Agotado implements EstadoProducto {
    public void manejar(Producto producto) {
        System.out.println("El producto está agotado.");
    }
}
