
public class Disponible implements EstadoProducto {
    public void manejar(Producto producto) {
        System.out.println("El producto está disponible.");
    }
}
