package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class principal extends JFrame {
	JFrame d; 

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					principal frame = new principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 800,  600);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Agregar Cliente");
		mnNewMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AgregarCliente a = new AgregarCliente();
				nuevopanel (a);

				
			}
		});
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("|");
		menuBar.add(mnNewMenu_1);
		
		JMenu mnNewMenu_2 = new JMenu("Realizar Pedido");
		mnNewMenu_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RealizarPedido r = new RealizarPedido();
				nuevopanel(r);

			}
		});
		menuBar.add(mnNewMenu_2);
		
		JMenu mnNewMenu_3 = new JMenu("|");
		menuBar.add(mnNewMenu_3);
		
		JMenu mnNewMenu_4 = new JMenu("Cancelar Pedido");
		mnNewMenu_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CancelarPedido c = new CancelarPedido();
				nuevopanel(c);

			}
		});
		menuBar.add(mnNewMenu_4);
		
		JMenu mnNewMenu_5 = new JMenu("|");
		menuBar.add(mnNewMenu_5);
		
		JMenu mnNewMenu_6 = new JMenu("Listar Clientes y Pedidos");
		mnNewMenu_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListarClientesyPedidos l = new ListarClientesyPedidos();
				nuevopanel(l);

			}
		});
		menuBar.add(mnNewMenu_6);
		
		JMenu mnNewMenu_7 = new JMenu("|");
		menuBar.add(mnNewMenu_7);
		
		JMenu mnNewMenu_8 = new JMenu("Listar Productos Disponibles");
		mnNewMenu_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListarProductosDisponibles L = new ListarProductosDisponibles();
				nuevopanel(L);

			}
		});
		menuBar.add(mnNewMenu_8);
		
		JMenu mnNewMenu_9 = new JMenu("|");
		menuBar.add(mnNewMenu_9);
		
		JMenu mnNewMenu_10 = new JMenu("Salir");
		menuBar.add(mnNewMenu_10);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Dell\\eclipse\\proyectos de eclipse o work space\\EmpresaLosGLobitos\\IMAGENS\\Captura de pantalla 2024-10-24 033724.png"));
		contentPane.add(lblNewLabel, "name_1091477749827500");
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		contentPane.add(lblNewLabel_1, "name_1091653480201300");
	}
	
	 public void nuevopanel(JPanel panelActual) {
		 contentPane.removeAll();
		 contentPane.add(panelActual);
		 contentPane.repaint();
		 contentPane.revalidate();
		 
		
	 }
}
