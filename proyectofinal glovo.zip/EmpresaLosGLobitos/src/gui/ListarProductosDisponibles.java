package gui;

import javax.swing.JPanel;

public class ListarProductosDisponibles extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public ListarProductosDisponibles() {

	}

}
