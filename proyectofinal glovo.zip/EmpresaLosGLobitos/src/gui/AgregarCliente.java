package gui;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class AgregarCliente extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public AgregarCliente() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ola");
		lblNewLabel.setBounds(300, 300, 400, 400);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(160, 112, 46, 40);
		add(lblNewLabel_1);

	}
}
