package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OrdenCompra extends JFrame {
    private JTextField nombreField;
    private JTextField numeroClienteField;

    public OrdenCompra() {
        setTitle("Orden de Compra");
        setSize(600, 400); // Aumentar el tamaño de la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout()); // Usar BorderLayout para dividir la ventana

        // Establecer fondo amarillo
        getContentPane().setBackground(Color.YELLOW);

        // Panel para los campos de entrada
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Espaciado entre componentes
        gbc.fill = GridBagConstraints.HORIZONTAL; // Para que los campos se expandan horizontalmente

        // Campos de entrada
        JLabel nombreLabel = new JLabel("Ingrese su nombre:");
        nombreField = new JTextField(15);
        
        JLabel numeroClienteLabel = new JLabel("Ingrese número de cliente:");
        numeroClienteField = new JTextField(15);

        JButton aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DetalleProducto().setVisible(true);
                dispose();  // Cerrar la ventana actual
            }
        });

        // Agregar componentes al panel de entrada
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER; // Centrar las etiquetas
        inputPanel.add(nombreLabel, gbc);

        gbc.gridy = 1; // Moverse a la siguiente fila
        inputPanel.add(nombreField, gbc);

        gbc.gridy = 2; // Moverse a la siguiente fila
        inputPanel.add(numeroClienteLabel, gbc);

        gbc.gridy = 3; // Moverse a la siguiente fila
        inputPanel.add(numeroClienteField, gbc);

        gbc.gridy = 4; // Moverse a la fila del botón
        inputPanel.add(aceptarButton, gbc);

        // Cargar la imagen (izquierda)
        try {
            ImageIcon imagenIzquierda = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/Captura de pantalla 2024-10-24 045813.png");
            JLabel labelImagenIzquierda = new JLabel(imagenIzquierda);
            labelImagenIzquierda.setPreferredSize(new Dimension(200, 400)); // Ajustar tamaño de la imagen
            add(labelImagenIzquierda, BorderLayout.WEST);  // Posicionamos la imagen a la izquierda
        } catch (Exception e) {
            System.out.println("Error al cargar la imagen izquierda: " + e.getMessage());
        }

        // Agregar el panel de entrada al centro de la ventana
        add(inputPanel, BorderLayout.CENTER);
    }
}

