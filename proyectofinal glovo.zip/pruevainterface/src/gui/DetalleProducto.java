package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DetalleProducto extends JFrame {
    private JTextField productoField;
    private JTextField cantidadField;
    private JTextField descripcionField;

    public DetalleProducto() {
        setTitle("Detalle del Producto");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        // Campos de entrada
        JLabel productoLabel = new JLabel("Ingrese nombre del producto:");
        productoField = new JTextField(15);

        JLabel cantidadLabel = new JLabel("Ingrese cantidad:");
        cantidadField = new JTextField(15);

        JLabel descripcionLabel = new JLabel("Ingrese descripción:");
        descripcionField = new JTextField(15);

        JButton aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ConfirmacionPedido().setVisible(true);
                dispose();  // Cerrar la ventana actual
            }
        });

        add(productoLabel);
        add(productoField);
        add(cantidadLabel);
        add(cantidadField);
        add(descripcionLabel);
        add(descripcionField);
        add(aceptarButton);
    }
}
