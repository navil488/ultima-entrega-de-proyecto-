package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CancelarProductos extends JFrame {
    public CancelarProductos() {
        setTitle("Cancelar Productos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Tabla de productos
        String[] columnNames = {"ID Producto", "Producto", "Cantidad", "Precio"};
        Object[][] data = {
            {1, "Globos", 100, 5.00},
            {2, "Sombrilla", 200, 50.00},
            {3, "Taza", 1500, 25.00},
            {4, "Boli", 1500, 25.00},
            {5, "Blocs de notas", 1500, 25.00}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // parte inferior
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        panel.add(new JLabel("Número de producto a cancelar:"));
        JTextField numeroProductoField = new JTextField();
        panel.add(numeroProductoField);

        panel.add(new JLabel("Ingrese su contraseña:"));
        JPasswordField contrasenaField = new JPasswordField();
        panel.add(contrasenaField);

        JCheckBox checkBox = new JCheckBox("¿Está seguro?");
        panel.add(checkBox);

        panel.add(new JLabel("Ingrese el motivo:"));
        JTextField motivoField = new JTextField();
        panel.add(motivoField);

        JButton aceptarButton = new JButton("Aceptar");
        panel.add(aceptarButton);

        add(panel, BorderLayout.SOUTH);

        // Acción del botón Aceptar
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkBox.isSelected()) {
                    new PedidoCancelado().setVisible(true);
                    dispose(); // Cerrar la ventana de cancelar productos
                } else {
                    JOptionPane.showMessageDialog(CancelarProductos.this, "Debes confirmar que estás seguro.");
                }
            }
        });
    }
}
