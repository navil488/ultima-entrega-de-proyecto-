package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CancelarProductosEmpleado extends JFrame {
    public CancelarProductosEmpleado() {
        setTitle("Cancelar Productos - Empleado");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Tabla de productos
        String[] columnNames = {"ID Producto", "Nombre", "Descripción", "Total"};
        Object[][] data = {
            {1, "Globos", "Globos de fiesta", 500.00},
            {2, "Sombrilla", "Sombrilla grande", 1000.00},
            {3, "Taza", "Taza personalizada", 3750.00},
            {4, "Boli", "Bolígrafos de colores", 3750.00},
            {5, "Blocs de notas", "Diseños personalizados", 3750.00}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        //  parte inferior
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        panel.add(new JLabel("Número de pedido a cancelar:"));
        JTextField numeroPedidoField = new JTextField();
        panel.add(numeroPedidoField);

        panel.add(new JLabel("Ingrese el motivo:"));
        JTextField motivoField = new JTextField();
        panel.add(motivoField);

        JButton cancelarButton = new JButton("Cancelar");
        panel.add(cancelarButton);

        add(panel, BorderLayout.SOUTH);

        // Acción del botón Cancelar
        cancelarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PedidoCancelado().setVisible(true);
                dispose(); // Cerrar la ventana de cancelar productos empleado
            }
        });
    }
}
