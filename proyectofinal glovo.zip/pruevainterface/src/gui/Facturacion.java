package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Facturacion extends JFrame {
    public Facturacion() {
        setTitle("Facturación");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        //  imagen de fondo
        ImageIcon fondoIcon = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/maxresdefault.jpg");
        JLabel labelFondo = new JLabel(fondoIcon);
        labelFondo.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Facturación", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE); // Cambiar el color de  letra a blanco

        // Crear un panel transparente para el título
        JPanel panelTitulo = new JPanel();
        panelTitulo.setOpaque(false); // Hacer el panel transparente
        panelTitulo.setLayout(new BorderLayout());
        panelTitulo.add(titleLabel, BorderLayout.CENTER);
        
        labelFondo.add(panelTitulo, BorderLayout.NORTH);

        // Datos de ejemplo no sirben miraar como aser q de conbd 
        String[][] datos = {
            {"LESTER1", "globos", "Código A001", "20", "5"},
            {"PEDRO", "sombrillas", "Código B002", "25", "50"},
            {"CARLOS 3", "tasas", "Código C003", "500", "25"}
        };

        String[] columnas = {"Cliente", "Producto", "Código", "Cantidad", "Costo"};

        JTable table = new JTable(datos, columnas);
        JScrollPane scrollPane = new JScrollPane(table);
        
        // Ajustar el scrollPane y la tabla
        scrollPane.setOpaque(false); // Hacer el scrollPane transparente
        scrollPane.getViewport().setOpaque(false); // Hacer el viewport del scrollPane transparente
        
        // Agregar un espacio antes de la tabla
        JPanel panelTabla = new JPanel();
        panelTabla.setOpaque(false); // Hacer el panel transparente
        panelTabla.setLayout(new BoxLayout(panelTabla, BoxLayout.Y_AXIS)); // BoxLayout para el espaciado vertical
        
        // Espacio superior
        panelTabla.add(Box.createVerticalStrut(20)); // Espaciado superior de 20 píxeles
        panelTabla.add(scrollPane); // Agregar la tabla al panel

        // Agregar el panelTabla al fondo
        labelFondo.add(panelTabla, BorderLayout.CENTER);

        // Crear un panel para el botón
        JPanel panelBoton = new JPanel();
        panelBoton.setOpaque(false); // Hacer el panel transparente
        JButton aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana
            }
        });
        panelBoton.add(aceptarButton); // Agregar el botón al panel

        // Agregar el panelBoton al fondo
        labelFondo.add(panelBoton, BorderLayout.SOUTH);

        // Agregar el fondo al JFrame
        add(labelFondo);

        setVisible(true);
    }
}
