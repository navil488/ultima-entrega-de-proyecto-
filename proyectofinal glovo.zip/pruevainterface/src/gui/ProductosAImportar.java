package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProductosAImportar extends JFrame {
    private JTextField numeroPedidoField;
    private JTextField cantidadField;
    private JTextField direccionField;

    public ProductosAImportar(String nombre, String id) {
        setTitle("Productos a Importar");
        setSize(600, 400);
        getContentPane().setBackground(Color.YELLOW);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Datos de los productos
        String[][] productos = {
            {"ID001", "Globos", "500", "25"},
            {"ID002", "Tazas", "200", "25"},
            {"ID003", "Camisas", "300", "25"}
        };

        String[] columnas = {"ID", "Producto", "Cantidad", "Precio"};

        JTable table = new JTable(productos, columnas);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // pedido
        JPanel panelPedido = new JPanel();
        panelPedido.setLayout(new GridLayout(4, 2));

        JLabel numeroPedidoLabel = new JLabel("Número de pedido:");
        numeroPedidoField = new JTextField();
        JLabel cantidadLabel = new JLabel("Cantidad:");
        cantidadField = new JTextField();
        JLabel direccionLabel = new JLabel("Dirección:");
        direccionField = new JTextField();

        JButton realizarPedidoButton = new JButton("Realizar Pedido");
        realizarPedidoButton.setBackground(Color.GREEN);
        realizarPedidoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ConfirmacionPedido().setVisible(true);
                dispose();  // Cerrar la ventana actual
            }
        });

        panelPedido.add(numeroPedidoLabel);
        panelPedido.add(numeroPedidoField);
        panelPedido.add(cantidadLabel);
        panelPedido.add(cantidadField);
        panelPedido.add(direccionLabel);
        panelPedido.add(direccionField);
        panelPedido.add(realizarPedidoButton);

        add(panelPedido, BorderLayout.SOUTH);
    }
}
