package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AgregarCliente extends JFrame {
    public AgregarCliente() {
        setTitle("Agregar Cliente");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(Color.YELLOW);  // Fondo amarillo

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  //separacion

        // Etiqueta 
        JLabel nombreLabel = new JLabel("Ingrese nombre de usuario:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nombreLabel, gbc);

        JTextField nombreField = new JTextField(20);
        gbc.gridx = 1;
        add(nombreField, gbc);

       
        JLabel contrasenaLabel = new JLabel("Ingrese contraseña:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(contrasenaLabel, gbc);

        JPasswordField contrasenaField = new JPasswordField(20);
        gbc.gridx = 1;
        add(contrasenaField, gbc);

      
        JLabel direccionLabel = new JLabel("Dirección:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(direccionLabel, gbc);

        JTextField direccionField = new JTextField(20);
        gbc.gridx = 1;
        add(direccionField, gbc);

        
        JLabel telefonoLabel = new JLabel("Número de teléfono:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(telefonoLabel, gbc);

        JTextField telefonoField = new JTextField(20);
        gbc.gridx = 1;
        add(telefonoField, gbc);

        // Botón Guardar
        JButton guardarButton = new JButton("Guardar");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;  
        add(guardarButton, gbc);

        // Etiqueta para mensaje de registro exitoso
        JLabel mensajeLabel = new JLabel();
        mensajeLabel.setForeground(Color.GREEN);  // Texto verde
        gbc.gridy = 5;
        add(mensajeLabel, gbc);

        // Acción del botón Guardar
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mensajeLabel.setText("Registro exitoso");  // Muestra el mensaje
                
            }
        });
    }
}
