package gui;

import javax.swing.*;
import java.awt.*;

public class IngresoEmpleado extends JFrame {
    public IngresoEmpleado() {
        setTitle("Ingreso Empleado");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel nombreLabel = new JLabel("Ingrese nombre de empleado:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nombreLabel, gbc);

        JTextField nombreField = new JTextField(20);
        gbc.gridx = 1;
        add(nombreField, gbc);

        JLabel idLabel = new JLabel("Ingrese ID de trabajador:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(idLabel, gbc);

        JTextField idField = new JTextField(20);
        gbc.gridx = 1;
        add(idField, gbc);

        JButton aceptarButton = new JButton("Aceptar");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(aceptarButton, gbc);

        // Acción del botón Aceptar
        aceptarButton.addActionListener(e -> {
           
            new CancelarProductosEmpleado().setVisible(true);
            dispose(); // Cerrar la ventana de ingreso de empleado
        });
    }
}
