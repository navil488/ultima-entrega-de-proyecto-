package gui;

import javax.swing.*;
import java.awt.*;

public class Cancelar extends JFrame {
    public Cancelar() {
        setTitle("Cancelar");
        setSize(600, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JButton btnCliente = new JButton("Cliente");
        JButton btnEmpleado = new JButton("Empleado");

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(btnCliente, gbc);

        gbc.gridx = 1;
        add(btnEmpleado, gbc);

        //  botón Cliente
        btnCliente.addActionListener(e -> new IngresoCliente().setVisible(true));
        
        //  botón Empleado
        btnEmpleado.addActionListener(e -> abrirInterfaceEmpleado());
    }

    private void abrirInterfaceEmpleado() {
        // Nueva ventana para ingresar datos del empleado
        JFrame empleadoFrame = new JFrame("Cancelar - Empleado");
        empleadoFrame.setSize(400, 300);
        empleadoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        empleadoFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Campos para ingresar datos de trabajador
        JLabel lblNombre = new JLabel("Nombre de Empleado:");
        JTextField txtNombre = new JTextField(20);
        JLabel lblId = new JLabel("ID de Trabajador:");
        JTextField txtId = new JTextField(20);
        JButton btnAceptar = new JButton("Aceptar");

       
        gbc.gridx = 0;
        gbc.gridy = 0;
        empleadoFrame.add(lblNombre, gbc);

        gbc.gridx = 1;
        empleadoFrame.add(txtNombre, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        empleadoFrame.add(lblId, gbc);

        gbc.gridx = 1;
        empleadoFrame.add(txtId, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        empleadoFrame.add(btnAceptar, gbc);

        // Acción del botón Aceptar
        btnAceptar.addActionListener(e -> {
            String nombre = txtNombre.getText();
            String id = txtId.getText();
        
            mostrarTablaProductos(empleadoFrame);
        });

        empleadoFrame.setVisible(true);
    }

    private void mostrarTablaProductos(JFrame empleadoFrame) {
        // Nueva ventana para mostrar la tabla de productos
        JFrame tablaFrame = new JFrame("Productos a Cancelar");
        tablaFrame.setSize(500, 300);
        tablaFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        tablaFrame.setLayout(new BorderLayout());

        //  columnas para la tabla
        String[] columnNames = {"ID", "Nombre del Producto", "Descripción", "Total"};
        Object[][] data = {
            {"1", "globos", "grandes", "455"},
            {"2", "camisas", "talla s ", "888"},
            
        };

        // Creación de la tabla
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        tablaFrame.add(scrollPane, BorderLayout.CENTER);

        // Campos para ingresar el número de pedido y el motivo a cancelar 
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblNumeroPedido = new JLabel("Número de Pedido:");
        JTextField txtNumeroPedido = new JTextField(20);
        JLabel lblMotivo = new JLabel("Motivo de la Cancelación:");
        JTextField txtMotivo = new JTextField(20);
        JButton btnCancelar = new JButton("Cancelar");

        // Añadiendo los componentes al panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblNumeroPedido, gbc);

        gbc.gridx = 1;
        panel.add(txtNumeroPedido, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(lblMotivo, gbc);

        gbc.gridx = 1;
        panel.add(txtMotivo, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(btnCancelar, gbc);

        // Acción del botón Cancelar
        btnCancelar.addActionListener(e -> {
            // 
            JOptionPane.showMessageDialog(tablaFrame, "Pedido cancelado.", "Cancelación", JOptionPane.INFORMATION_MESSAGE);
            tablaFrame.dispose();
        });

        // 
        tablaFrame.add(panel, BorderLayout.SOUTH);
        tablaFrame.setVisible(true);
        empleadoFrame.dispose(); // Cerrar la ventana de empleado
    }
}
