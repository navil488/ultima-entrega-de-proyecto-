package gui;

import java.awt.BorderLayout;
//import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class Display_1 extends JFrame {

	//JFrame d; 
	
	//public Display_1 () {
	//	d = new JFrame () ;
	//	d.setVisible(true);// PARA Q SE MIRE EL CUADRITO
		//d.setBounds(300, 300, 400, 400); // LAS LONGITUDES LOS PRIMEROS SON DONDE APARESE Y LOS ULTIMOS DOS SON EL ANCHO Y LARGO 
		//d.setDefaultCloseOperation(EXIT_ON_CLOSE);// si se sierra la ventana deja de ejecutar el codigo 
	//	d.setTitle("ORDEN DE COMPRA");// el titulo  de la ventana
		
		
		//esto es para que  no se pierda la pantallita 
	//	d.addFocusListener(new FocusListener() {

		//	@Override
		//	public void focusGained(FocusEvent e) {
	//			System.out.println("ventana avierta ");
				
		//	}

		//	@Override
			//public void focusLost(FocusEvent e) {    // esto es para que parpade la ventana cuando se muesta en  la barra
			//	d.requestFocus();
				
			
			
		//	ImageIcon imagenIzquierda = new ImageIcon("ruta/a/la/imagen.png");
			//Image imagen = imagenIzquierda.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH); // Cambia el tamaño según sea necesario
		//	labelImagenIzquierda.setIcon(new ImageIcon(imagen));

			
			
		//	 JFrame mainFrame = new JFrame("Aplicación");
		  //      mainFrame.setSize(600, 500);  // Aumentamos el tamaño de la ventana
		  //      mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  //.setLayout(new BorderLayout());  
		        // Panel para el título
		//        JPanel panelTitulo = new JPanel();
		   //     panelTitulo.setBackground(Color.BLACK); // Fondo negro
		  ///      JLabel lblTitulo = new JLabel("Menú Principal");
		 //       lblTitulo.setForeground(Color.WHITE); // Texto blanco
		    //    lblTitulo.setFont(new Font("Arial", Font.BOLD, 24)); // Negrita
		//        panelTitulo.add(lblTitulo);

	//	        // Panel central con botones
		//        JPanel panelCentral = new JPanel(new GridBagLayout());
		//        GridBagConstraints gbc = new GridBagConstraints();
		       // gbc.insets = new Insets(10, 10, 10, 10);  // Margen entre los botones

		        // Creación de botones
		   //     JButton btnOrdenCompra = new JButton("Orden de Compra");
		  //   // Cargar la imagen de fondo
   // ImageIcon fondoIcon = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/maxresdefault.jpg");
  //  JLabel labelFondo = new JLabel(fondoIcon);
  //  labelFondo.setLayout(new BorderLayout());

  //  // Cargar la imagen izquierda
  //  try {
   //     ImageIcon imagenIzquierda = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/Captura de pantalla 2024-10-24 045813.png");
    //    JLabel labelImagenIzquierda = new JLabel(imagenIzquierda);
    //    labelFondo.add(labelImagenIzquierda, BorderLayout.WEST);  // Posicionamos la imagen a la izquierda
  //  } catch (Exception e) {
    //    System.out.println("Error al cargar la imagen izquierda: " + e.getMessage());
   // }

    /// Cargar la imagen derecha
  //  try {
   //     ImageIcon imagenDerecha = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/Captura de pantalla 2024-10-24 033724.png");
    //    JLabel labelImagenDerecha = new JLabel(imagenDerecha);
    //    labelFondo.add(labelImagenDerecha, BorderLayout.EAST);  // Posicionamos la imagen a la derecha
   // } catch (Exception e) {
  //      System.out.println("Error al cargar la imagen derecha: " + e.getMessage());
  //  }

    // Añadir el panel del título y los botones sobre la imagen de fondo
   // labelFondo.add(panelTitulo, BorderLayout.NORTH);
  //  labelFondo.add(panelCentral, BorderLayout.CENTER);
  //  mainFrame.add(labelFondo); // Agregamos el JLabel con la imagen de fondo al JFrame

    // Hacemos visible el JFrame
    //mainFrame.setVisible(true);
	
	
//  // Establecer fondo amarillo
  //  getContentPane().setBackground(Color.YELLOW);}
}

