package gui;

import javax.swing.*;
import java.awt.*;

public class ConfirmacionPedido extends JFrame {
    public ConfirmacionPedido() {
        setTitle("Confirmación de Pedido");
        setSize(400, 300); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Espaciado entre componentes

        // Mensaje de confirmación
        JLabel mensajeLabel = new JLabel("¡Pedido realizado!");
        mensajeLabel.setFont(new Font("Arial", Font.BOLD, 20)); // Estilo del texto
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER; // Centrar el mensaje
        add(mensajeLabel, gbc);

        
        JTextArea asciiArtArea = new JTextArea();
        asciiArtArea.setText(" __\n" +
                "                     .'  '.\n" +
                "                 _.-'/  |  \\\n" +
                "    ,        _.-\"  ,|  /  0 `-.\n" +
                "    |\\    .-\"       `--\"-.__.'=====================-,\n" +
                "    \\ '-'`        .___.--._)=========================|\n" +
                "     \\            .'      |                          |\n" +
                "      |     /,_.-'        |        GRASIAS            |\n" +
                "    _/   _.'(             |           POR            |\n" +
                "   /  ,-' \\  \\            |       SU  COMPRA         |\n" +
                "   \\  \\    `-'            |                          |\n" +
                "    `-'                   '--------------------------'");
        
        asciiArtArea.setFont(new Font("Monospaced", Font.PLAIN, 12)); // Fuente 
        asciiArtArea.setEditable(false); //para  Hacer el area no editable
        asciiArtArea.setBackground(getBackground()); // Mantener el fondo igual
        asciiArtArea.setLineWrap(false); // No permitir el salto de líneas
        asciiArtArea.setWrapStyleWord(false); // No envolver palabras

        gbc.gridy = 1; // Mover a la siguiente fila
        add(asciiArtArea, gbc);
    }
}
