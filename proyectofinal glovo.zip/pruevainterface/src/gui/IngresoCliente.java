package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IngresoCliente extends JFrame {
    public IngresoCliente() {
        setTitle("Ingreso Cliente");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel nombreLabel = new JLabel("Ingrese su nombre:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nombreLabel, gbc);

        JTextField nombreField = new JTextField(20);
        gbc.gridx = 1;
        add(nombreField, gbc);

        JLabel codigoLabel = new JLabel("Ingrese su código:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(codigoLabel, gbc);

        JTextField codigoField = new JTextField(20);
        gbc.gridx = 1;
        add(codigoField, gbc);

        JButton aceptarButton = new JButton("Aceptar");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(aceptarButton, gbc);

        aceptarButton.addActionListener(e -> {
           
            new CancelarProductos().setVisible(true);
            dispose(); // Cerrar la ventana de ingreso de cliente
        });
    }
}
