package gui;

import javax.swing.*;
import java.awt.*;

public class main {
    public static void main(String[] args) {
        JFrame mainFrame = new JFrame("Aplicación");
        mainFrame.setSize(600, 500);  // Aumentamos el tamaño de la ventana
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLayout(new BorderLayout());  
        // Panel para el título
        JPanel panelTitulo = new JPanel();
        panelTitulo.setBackground(Color.BLACK); // Fondo negro
        JLabel lblTitulo = new JLabel("Menú Principal");
        lblTitulo.setForeground(Color.WHITE); // Texto blanco
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24)); // Negrita
        panelTitulo.add(lblTitulo);

        // Panel central con botones
        JPanel panelCentral = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Margen entre los botones

        // Creación de botones
        JButton btnOrdenCompra = new JButton("Orden de Compra");
        JButton btnOrdenVenta = new JButton("Agregar cliente");
        JButton btnProduccion = new JButton("Producción");
        JButton btnImportacion = new JButton("Importación");
        JButton btnFacturacion = new JButton("Facturación");
        JButton btnCancelar = new JButton("Cancelar"); // Botón de Cancelar

        //  acciones a los botones
        btnOrdenCompra.addActionListener(e -> new OrdenCompra().setVisible(true));
        btnOrdenVenta.addActionListener(e -> new OrdenVenta().setVisible(true));
        btnProduccion.addActionListener(e -> new Produccion().setVisible(true));
        btnImportacion.addActionListener(e -> new Importacion().setVisible(true));
        btnFacturacion.addActionListener(e -> new Facturacion().setVisible(true));
        btnCancelar.addActionListener(e -> new Cancelar().setVisible(true));
        // pusimos los botones al panel usando GridBagLayout para centrarlos
        
        gbc.gridx = 1;  // Posición centrada (columna 1)
        gbc.gridy = 0;
        panelCentral.add(btnOrdenCompra, gbc);

        gbc.gridy = 1;
        panelCentral.add(btnOrdenVenta, gbc);

        gbc.gridy = 2;
        panelCentral.add(btnProduccion, gbc);

        gbc.gridy = 3;
        panelCentral.add(btnImportacion, gbc);

        gbc.gridy = 4;
        panelCentral.add(btnFacturacion, gbc);

        gbc.gridy = 5; 
        panelCentral.add(btnCancelar, gbc); 

        // Cargar la imagen de fondo
        ImageIcon fondoIcon = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/maxresdefault.jpg");
        JLabel labelFondo = new JLabel(fondoIcon);
        labelFondo.setLayout(new BorderLayout());

        // Cargar la imagen izquierda
        try {
            ImageIcon imagenIzquierda = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/Captura de pantalla 2024-10-24 045813.png");
            JLabel labelImagenIzquierda = new JLabel(imagenIzquierda);
            labelFondo.add(labelImagenIzquierda, BorderLayout.WEST);  // Posicionamos la imagen a la izquierda
        } catch (Exception e) {
            System.out.println("Error al cargar la imagen izquierda: " + e.getMessage());
        }

        // Cargar la imagen derecha
        try {
            ImageIcon imagenDerecha = new ImageIcon("C:/Users/Dell/eclipse/proyectos de eclipse o work space/pruevainterface/imagenes/Captura de pantalla 2024-10-24 033724.png");
            JLabel labelImagenDerecha = new JLabel(imagenDerecha);
            labelFondo.add(labelImagenDerecha, BorderLayout.EAST);  // Posicionamos la imagen a la derecha
        } catch (Exception e) {
            System.out.println("Error al cargar la imagen derecha: " + e.getMessage());
        }

        // Añadir el panel del título y los botones sobre la imagen de fondo
        labelFondo.add(panelTitulo, BorderLayout.NORTH);
        labelFondo.add(panelCentral, BorderLayout.CENTER);
        mainFrame.add(labelFondo); // Agregamos el JLabel con la imagen de fondo al JFrame

        // Hacemos visible el JFrame
        mainFrame.setVisible(true);
    }

    public void setVisible(boolean b) {
        // TODO Auto-generated method stub
    }
    
    // no olbidar lo de mdb
}

