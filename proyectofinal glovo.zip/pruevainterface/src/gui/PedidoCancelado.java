package gui;

import javax.swing.*;
import java.awt.*;

public class PedidoCancelado extends JFrame {
    public PedidoCancelado() {
        setTitle("Pedido Cancelado");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel mensajeLabel = new JLabel("Pedido Cancelado");
        mensajeLabel.setForeground(Color.RED);
        mensajeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(mensajeLabel, gbc);

        JLabel emoticonLabel = new JLabel("(╥_╥)");
        emoticonLabel.setFont(new Font("Arial", Font.PLAIN, 48));
        gbc.gridy = 1;
        add(emoticonLabel, gbc);
    }
}
