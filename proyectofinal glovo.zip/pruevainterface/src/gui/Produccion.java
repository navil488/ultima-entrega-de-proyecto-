package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

class Producto {
    String nombre;
    String formato;
    String descripcion;
    int stock;
    double precio;

    public Producto(String nombre, String formato, String descripcion, int stock, double precio) {
        this.nombre = nombre;
        this.formato = formato;
        this.descripcion = descripcion;
        this.stock = stock;
        this.precio = precio;
    }
}

public class Produccion extends JFrame {
    public Produccion() {
        setTitle("Producción");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Productos Disponibles", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, BorderLayout.NORTH);

        // Lista de productos disponibles
        List<Producto> productosDisponibles = new ArrayList<>();
        productosDisponibles.add(new Producto("Globos", "Grande", "Rojo", 100, 5.00));
        productosDisponibles.add(new Producto("Sombrilla", "Grande", "Negra", 200, 50.00));
        productosDisponibles.add(new Producto("Taza", "Taza de 1.5 ml", "1500", 1500, 25.00));
        productosDisponibles.add(new Producto("Boli", "Bolígrafos personalizados", "De colores", 1500, 25.00));
        productosDisponibles.add(new Producto("Blocs de notas", "Con diseños personalizados", "Hojas", 1500, 25.00));
        productosDisponibles.add(new Producto("Llaveros", "Llaveros personalizados", "Colgante", 1500, 25.00));
        productosDisponibles.add(new Producto("USB", "USB personalizado", "Negro", 1050, 50.00));
        productosDisponibles.add(new Producto("Power Bank", "Personalizado", "Negro", 1500, 250.00));
        productosDisponibles.add(new Producto("Gorras", "Personalizadas", "De colores", 1500, 200.00));
        productosDisponibles.add(new Producto("Camisas", "Personalizadas", "Fosforescentes", 1050, 250.00));

        // Crear la tabla
        String[] columnas = {"Producto", "Formato", "Descripción", "Stock", "Precio Unitario"};
        String[][] datos = new String[productosDisponibles.size()][5];

        for (int i = 0; i < productosDisponibles.size(); i++) {
            Producto p = productosDisponibles.get(i);
            datos[i][0] = p.nombre;
            datos[i][1] = p.formato;
            datos[i][2] = p.descripcion;
            datos[i][3] = String.valueOf(p.stock);
            datos[i][4] = String.valueOf(p.precio);
        }

        JTable table = new JTable(datos, columnas);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Botón Aceptar
        JButton aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new main().setVisible(true);  // Regresar al menú principal
                dispose();  // Cerrar la ventana actual
            }
        });
        add(aceptarButton, BorderLayout.SOUTH);
    }
}
