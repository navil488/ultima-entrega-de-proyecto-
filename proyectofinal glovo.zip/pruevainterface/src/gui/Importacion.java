package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Importacion extends JFrame {
    private JTextField nombreField;
    private JTextField idField;

    public Importacion() {
        setTitle("Importación");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        // Campo para el nombre del usuario
        JLabel nombreLabel = new JLabel("Ingrese su nombre:", SwingConstants.CENTER);
        nombreField = new JTextField(15);
        nombreField.setHorizontalAlignment(SwingConstants.CENTER);

        // Campo para el ID del trabajador
        JLabel idLabel = new JLabel("Ingrese ID de trabajador:", SwingConstants.CENTER);
        idField = new JTextField(15);
        idField.setHorizontalAlignment(SwingConstants.CENTER);

        // Botón de aceptar
        JButton aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ProductosAImportar(nombreField.getText(), idField.getText()).setVisible(true);
                dispose();  // Cerrar la ventana actual
            }
        });

        // Agregar componentes a la interfaz
        add(nombreLabel);
        add(nombreField);
        add(idLabel);
        add(idField);
        add(aceptarButton);
    }
}
